/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kerucut;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author Asus
 */
public class CodinganKerucut {
    public static void main(String[] args) throws IOException {
    BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
    ProsesKerucut Kerucut = new ProsesKerucut ();
    try
    {
        System.out.println("Inputkan jari-jari");
        String r = dataIn.readLine ();
        Kerucut.setJari(Integer.parseInt (r));
        
        System.out.println("Inputkan Tinggi");
        String t = dataIn.readLine ();
        Kerucut.setTinggi (Integer.parseInt (t));
        
        System.out.println("JariJari Kerucut="+Kerucut.getJari());
        System.out.println("Tinggi Kerucut="+Kerucut.getTinggi());
        System.out.println("Volume Kerucut="+Kerucut.hitungVolume());
        
    }
    catch (IOException e)
    
    {
    
        
    }
    
}

}