/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limas;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Asus
 */
public class CodinganLimas {
    public static void main(String[] args) {
    BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
    Limas.ProsesLimas Limas = new Limas.ProsesLimas ();
    try
    {
        System.out.println("Inputkan Luas");
        String s = dataIn.readLine();
        Limas.setLuas (Integer.parseInt(s));
        
        System.out.println("Inputkan Tinggi");
        String b = dataIn.readLine();
        Limas.setTinggi (Integer.parseInt(b));
                
        System.out.println("Luas Limas="+Limas.getLuas());
        System.out.println("Tinggi Limas="+Limas.getTinggi());
        System.out.println("Volume Limas="+Limas.hitungVolume());
    }
    catch (IOException e)
    {
        
    }
        
       
    }
}
