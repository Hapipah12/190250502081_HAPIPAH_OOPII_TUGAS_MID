/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limas;

/**
 *
 * @author Asus
 */
public class ProsesLimas {
    private int Luas;
     private int Tinggi;
     
     public void setSisi (int sisi)
    {
        int luas = 0;
        this.Luas = luas;
    } 
    public void set(int tinggi)
    {
        this.Tinggi = tinggi;  
    }
    
     public int getLuas()
    {   
    return Luas;
    }
    public int getTinggi()
    {
     return Tinggi;
    }
   
     public double hitungVolume ()
{
    double Volume;
    Volume = Luas*Tinggi*1/3;
    return Volume; 
}

    void setTinggi(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setLuas(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
}

    

