/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Prisma;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Asus
 */
public class CodinganPrisma {
    public static void main(String[] args) throws IOException {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Prisma.ProsesPrisma Prisma = new Prisma.ProsesPrisma();
       try
       {
           System.out.println("Inputkan luas alas");
           String a= dataIn.readLine();
           Prisma.setAlas(Integer.parseInt(a));
           
           System.out.println("Inputkan tinggi");
           String m = dataIn.readLine();
           Prisma.setTinggi (Integer.parseInt(m));
           
           System.out.println("luas alas prisma="+Prisma.getAlas());
           System.out.println("keliling prisma="+Prisma.getKeliling());
           System.out.println("tinggi prisma="+Prisma.getTinggi ());
           System.out.println("Luas Prisma="+Prisma.hitungLuas());
           System.out.println("Volume Prisma="+Prisma.hitungVolume());
           
     
       }
      catch (IOException e)
      {
    
      }
    }
    

}
    
    

