/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Prisma;

/**
 *
 * @author Asus
 */
public class ProsesPrisma {
     private int Alas;
     private int Tinggi;
     private int Keliling;
     
    public void setAlas(int alas)
    {
        this.Alas = alas;
    }
    public void setTinggi(int tinggi)
    {
        this.Tinggi = tinggi;  
    }
     public void setKeliling(int keliling)
    {
        this.Keliling = keliling;  
    }
      public int getAlas()
    {   
    return Alas;
    }
    public int getTinggi()
    {
     return Tinggi;
    }
     public int getKeliling()
    {
     return Keliling;
    }
     public double hitungVolume()
{
    double Volume;
    Volume = ((Alas *Tinggi)/2)*Tinggi;
    return Volume;        
}
    public double hitungLuas()
{
    double Luas;
    Luas =(2*Alas)+ (Keliling*Tinggi);
    return Luas; 
}

}
