/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabung;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


/**
 *
 * @author Asus
 */
public class CodinganTabung {
    public static void main(String[] args) throws IOException{
    BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
    Tabung.ProsesTabung Tabung = new Tabung.ProsesTabung ();
    try
    {
        System.out.println("Inputkan Jarijari");
        String r = dataIn.readLine();
        Tabung.setJarijari(Integer.parseInt (r));
        
        System.out.println("Inputkan Tinggi");
        String t = dataIn.readLine();
        Tabung.setJarijari(Integer.parseInt (t));
        
        System.out.println("Jarijari Tabung="+Tabung.getJarijari ());
        System.out.println("Tinggi Tabung="+Tabung.getTinggi ());
        System.out.println("Volume Tabung="+Tabung.hitungVolume());
        
    }
     catch (IOException e)
     {
        
    }
    
}
}
