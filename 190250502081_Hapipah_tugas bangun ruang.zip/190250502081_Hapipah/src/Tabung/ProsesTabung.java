/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tabung;

/**
 *
 * @author Asus
 */
public class ProsesTabung {
      private int Jarijari;
     private int Tinggi;
    
    public void setJarijari(int jarijari)
    {
        this.Jarijari = jarijari;
    }
    public void setTinggi(int tinggi)
    {
        this.Tinggi = tinggi;  
    }
        
    public int getJarijari()
    {   
    return Jarijari;
    }
    public int getTinggi()
    {
     return Tinggi;
    }
        
    public double hitungVolume ()
{
    double Volume;
    Volume = 3.14*Jarijari* Tinggi;
    return Volume;
}
    



    
    
}


